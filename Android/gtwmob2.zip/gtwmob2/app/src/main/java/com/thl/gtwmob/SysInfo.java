package com.thl.gtwmob;

public class SysInfo {

    public String netWorkType;
    public Integer[] memory;
    public int signalStrength;
    public Double[] location;
    public Boolean[] conType;
    public Float cpuTemp;
    public Float batTemp;
    public Float batLevel;

}
