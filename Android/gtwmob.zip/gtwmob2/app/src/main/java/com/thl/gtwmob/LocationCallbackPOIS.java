package com.thl.gtwmob;

public interface LocationCallbackPOIS {

    void callback(String subject,Double[] location);
}
