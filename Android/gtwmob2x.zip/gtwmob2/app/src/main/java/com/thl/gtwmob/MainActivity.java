package com.thl.gtwmob;

import android.Manifest;
import android.accounts.AccountManager;
import android.app.Dialog;
//import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
//import android.view.Menu;
//import android.view.MenuItem;
//import android.widget.EditText;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential;
//import com.google.api.client.googleapis.util.Utils;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.ExponentialBackOff;
import com.google.api.services.gmail.Gmail;
import com.google.api.services.gmail.GmailScopes;
import com.google.api.services.gmail.model.ListMessagesResponse;
import com.google.api.services.gmail.model.Message;
//import com.google.api.services.gmail.model.MessagePart;
import com.google.api.services.gmail.model.MessagePartHeader;
import com.google.api.services.gmail.model.ModifyMessageRequest;

import java.io.IOException;
//import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutionException;

import com.thl.gtwmob.helper.InternetDetector;
import com.thl.gtwmob.helper.Utilsx;

import org.json.JSONObject;

import static com.thl.gtwmob.helper.Utilsx.REQUEST_PERMISSION_ACCESS_FINE_LOCATION;
import static com.thl.gtwmob.helper.Utilsx.REQUEST_PERMISSION_GET_ACCOUNTS;
import static com.thl.gtwmob.helper.Utilsx.readJSONFromAsset;
import static java.lang.Thread.sleep;


public class MainActivity extends AppCompatActivity implements Callback {

    public static final int MY_PERMISSIONS_REQUEST_READ_CONTACTS = 1004;
    private static Handler handler;
    FloatingActionButton sendFabButton;
    private GoogleAccountCredential mCredential;
    //private static final String PREF_ACCOUNT_NAME = "accountName";
    private String PREF_ACCOUNT_NAME; // = "gtw.mob@gmail.com";
    private static final String[] SCOPES = {
            GmailScopes.GMAIL_LABELS,
            GmailScopes.GMAIL_COMPOSE,
            GmailScopes.GMAIL_INSERT,
            GmailScopes.GMAIL_MODIFY,
            GmailScopes.GMAIL_READONLY,
            GmailScopes.MAIL_GOOGLE_COM
    };
    private InternetDetector internetDetector;
    private timerProg tp;

    private boolean working=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

                msg(view);

                //tp.init(false);

            }
        });

        //test();
        init();
        tp = new timerProg(0, this, 4000);
//        test2();

        //msg();
    }


    private boolean fakeProcess(){

        try {
            Log.v("xxx", "fakeProcess starts");
            sleep(10000);
            Log.v("xxx", "fakeProcess ends");
            return true;
        }catch(Exception ex){

            Log.v("xxx",ex.getMessage());
        }
        return false;
    }

    public boolean callbackxxx(String str) {

        Log.v("xxx", str);

/*
        try {
            //String data=getWeather();
            //System.out.println("xxxxx " + data);
            //String result=getLocalhost(data);
            //System.out.println("xxxxx " + result);
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
*/
        // otetaanko dataa talteen vai yksittäin lähtetään expressille vai suoraan kantaan
        // toisaalta express voisi ilman Androida löueka suoraan mutta demo ytarkoituksessa gatewqay
        //
        //System.out.println("xxxx Callback täältä lähtetään tietokantaan "+str);
        return true;
    }

    private void test2() {

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Permission is not granted
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
            } else {
                // No explanation needed; request the permission
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        REQUEST_PERMISSION_ACCESS_FINE_LOCATION);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        } else {
            // Permission has already been granted
        }

    }

    private void test() {

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.GET_ACCOUNTS)
                != PackageManager.PERMISSION_GRANTED) {

            // Permission is not granted
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.GET_ACCOUNTS)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
            } else {
                // No explanation needed; request the permission
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.GET_ACCOUNTS},
                        REQUEST_PERMISSION_GET_ACCOUNTS);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        } else {
            // Permission has already been granted
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case REQUEST_PERMISSION_GET_ACCOUNTS: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    Log.v("xxx", "requestCode=" + requestCode + "   " + "GRANTED");
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    Log.v("xxx", "requestCode=" + requestCode + "   " + "DENIED");
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                return;
            }
            case REQUEST_PERMISSION_ACCESS_FINE_LOCATION: {

                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    Log.v("xxx", "requestCode=" + requestCode + "   " + "GRANTED");
                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {
                    Log.v("xxx", "requestCode=" + requestCode + "   " + "DENIED");
                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                }
                //return;
            }

            // other 'case' lines to check for other
            // permissions this app might request.
        }
    }

    private void msg(View view) {

        // pitäisi ensin tarkistaa onko kirjauduttu ja sitähän varten on ewimerkkikoodissa
        // getResultsFromApi
        //new ReadMessageTask(this,mCredential).execute();

        getResultsFromApi(view);

        //subFunc_1();

    }

    private void subFunc_1() {


    }

    // pitöisikö olla ReadMesageTask-luokassa kaikki
    private void getResultsFromApi(View view) {

        //Log.v("xxx", "#########");

        //try {
        if (!internetDetector.checkMobileInternetConn()) {
            Log.v("xxx", "#5");
            showMessage(view, "No network connection available.");
            Log.v("xxx", "#6");
        } else if (!isGooglePlayServicesAvailable()) {

            Log.v("xxx", "#1");
            acquireGooglePlayServices();
            Log.v("xxx", "#2");
        } else if (mCredential.getSelectedAccountName() == null) {
            //showMessage(view,"cHOOSE account");
            Log.v("xxx", "#3");
            chooseAccount(view);
            Log.v("xxx", "#4");
            // tämä kokeeksi mahd, else:ssö pois

            //new ReadMessageTask(1,mCredential,getResources().getString(R.string.app_name),PREF_ACCOUNT_NAME,this).execute();

            // jos tömöö toimii niin ehto pois ja loppuun
            //new ReadMessageTask(1,mCredential,getResources().getString(R.string.app_name),PREF_ACCOUNT_NAME,this).execute();


            //String result =new ReadMessageTask(mCredential,getResources().getString(R.string.app_name),PREF_ACCOUNT_NAME).execute().get();
            //String result= new ReadMessageTask().execute("xxx").get();

            //Log.§v("xxx", "result="+result);

                /*
                ReadMessageTask rmt=new ReadMessageTask(mCredential); //mCredential,this).execute();

                String result = rmt.execute().get();
                */
            //Log.v("xxx", "########"+result);
            //} /*else if (!Utils.isNotEmpty(edtToAddress) && task == 1) {
          /*  showMessage(view, "To address Required");
        } else if (!Utils.isNotEmpty(edtSubject) && task == 1) {
            showMessage(view, "Subject Required");
        } else if (!Utils.isNotEmpty(edtMessage) && task == 1) {
            showMessage(view, "Message Required");*/
            //}
        } else {
            //Log.v("xxx", "#7");
            ////new ReadMessageTask(mCredential).execute();
            //new ReadMessageTask(1,mCredential,getResources().getString(R.string.app_name),PREF_ACCOUNT_NAME,this).execute();
            //Log.v("xxx", "#8");
        }
        new ReadMessageTask(1, mCredential, getResources().getString(R.string.app_name), PREF_ACCOUNT_NAME, this).execute();
        /*} catch (Exception ex) {

            Log.v("xxx", "Error =" + ex.getMessage());
        }*/
    }

    // Method for Checking Google Play Service is Available
    private boolean isGooglePlayServicesAvailable() {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int connectionStatusCode = apiAvailability.isGooglePlayServicesAvailable(this);
        return connectionStatusCode == ConnectionResult.SUCCESS;
    }

    // Method to Show Info, If Google Play Service is Not Available.
    private void acquireGooglePlayServices() {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int connectionStatusCode = apiAvailability.isGooglePlayServicesAvailable(this);
        if (apiAvailability.isUserResolvableError(connectionStatusCode)) {
            showGooglePlayServicesAvailabilityErrorDialog(connectionStatusCode);
        }
    }

    // Method for Google Play Services Error Info
    void showGooglePlayServicesAvailabilityErrorDialog(final int connectionStatusCode) {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        Dialog dialog = apiAvailability.getErrorDialog(
                MainActivity.this,
                connectionStatusCode,
                Utilsx.REQUEST_GOOGLE_PLAY_SERVICES);
        dialog.show();
    }

    // Storing Mail ID using Shared Preferences
    private void chooseAccount(View view) {

        if (Utilsx.checkPermission(getApplicationContext(), Manifest.permission.GET_ACCOUNTS)) {

            Log.v("xxx", "PREF_ACCOUNT_NAME= " + PREF_ACCOUNT_NAME);
            String accountName = getPreferences(Context.MODE_PRIVATE).getString(PREF_ACCOUNT_NAME, null);
            if (accountName != null) {

                Log.v("xxx", "#1#accountName= " + accountName);
                mCredential.setSelectedAccountName(accountName);
                Log.v("xxx", "#2#accountName= " + accountName);
                //getResultsFromApi(view);
                Log.v("xxx", "#3#accountName= " + accountName);
            } else {
                // Start a dialog from which the user can choose an account
                Log.v("xxx", "accountName will be asked");
                startActivityForResult(mCredential.newChooseAccountIntent(), Utilsx.REQUEST_ACCOUNT_PICKER);
            }
        } else {
            Log.v("xxx", "Request for permission ");
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.GET_ACCOUNTS}, REQUEST_PERMISSION_GET_ACCOUNTS);
        }
    }

    private void showMessage(View view, String message) {
        Snackbar.make(view, message, Snackbar.LENGTH_LONG).show();
    }

    private void init() {
        // Initializing Internet Checker

        Context context = getApplicationContext();

        String str = readJSONFromAsset("settings.json", context);

        try {
            JSONObject reader = new JSONObject(str);
            String email = reader.getString("email");
            PREF_ACCOUNT_NAME = email;
            //Log.v("xxx", "Assetval= " + str + "      " + email);
        } catch (Exception ex) {

            Log.v("xxx", "###### " + ex.getMessage());
        }

        Log.v("xxx", "#1 init ");
        internetDetector = new InternetDetector(getApplicationContext());

        Log.v("xxx", "#2 init ");
        // Initialize credentials and service object.
        mCredential = GoogleAccountCredential.usingOAuth2(
                getApplicationContext(), Arrays.asList(SCOPES))
                .setBackOff(new ExponentialBackOff());

        /*
        try {
            String result = new RequestPermissionTask(this).execute().get();
            Log.v("xxx", "#3 init "+result);
        }catch(Exception ex){

            Log.v("xxx","Error: "+ex.getMessage());
        }*/

        // HUOM tsekkaa oma dialogi Android ht:stä siellä oma dialogi joka odottaa!!!!!
        // Looper.loop()


        /*
        handler = new Handler();

        Log.v("xxx", "#3 init ");
        ActivityCompat.requestPermissions(MainActivity.this,
                new String[]{Manifest.permission.GET_ACCOUNTS}, REQUEST_PERMISSION_GET_ACCOUNTS);
        Log.v("xxx", "#4 init ");

        if (handler != null) {
            try {
                Looper.loop();
            } catch (
                    RuntimeException e) {
            }
        }
        Log.v("xxx", "#4 init ");
        */
        // Initializing Progress Dialog
        /*
        mProgress = new ProgressDialog(this);
        mProgress.setMessage("Sending...");

        toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        sendFabButton = (FloatingActionButton) findViewById(R.id.fab);
        readMessageFabButton = (FloatingActionButton) findViewById(R.id.fab2);
        edtToAddress = (EditText) findViewById(R.id.to_address);
        edtSubject = (EditText) findViewById(R.id.subject);
        edtMessage = (EditText) findViewById(R.id.body);
        edtAttachmentData = (EditText) findViewById(R.id.attachmentData);
        */
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.v("xxx", "resultCode=" + resultCode);
        switch (requestCode) {
            case Utilsx.REQUEST_GOOGLE_PLAY_SERVICES:
                if (resultCode != RESULT_OK) {
                    showMessage(sendFabButton, "This app requires Google Play Services. Please install " +
                            "Google Play Services on your device and relaunch this app.");
                } else {
                    getResultsFromApi(sendFabButton);
                }
                break;
            case Utilsx.REQUEST_ACCOUNT_PICKER:
                if (resultCode == RESULT_OK && data != null && data.getExtras() != null) {
                    String accountName = data.getStringExtra(AccountManager.KEY_ACCOUNT_NAME);
                    if (accountName != null) {
                        SharedPreferences settings = getPreferences(Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = settings.edit();
                        editor.putString(PREF_ACCOUNT_NAME, accountName);
                        editor.apply();
                        mCredential.setSelectedAccountName(accountName);
                        getResultsFromApi(sendFabButton);
                    }
                }
                break;
            case Utilsx.REQUEST_AUTHORIZATION:
                if (resultCode == RESULT_OK) {
                    getResultsFromApi(sendFabButton);
                }
                /*break;
            case SELECT_PHOTO:
                if (resultCode == RESULT_OK) {
                    final Uri imageUri = data.getData();
                    fileName = getPathFromURI(imageUri);
                    edtAttachmentData.setText(fileName);
                }*/
        }
    }

    /*
        public String getPathFromURI(Uri contentUri) {
            String res = null;
            String[] proj = {MediaStore.Images.Media.DATA};
            Cursor cursor = getContentResolver().query(contentUri, proj, "", null, "");
            assert cursor != null;
            if (cursor.moveToFirst()) {
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                res = cursor.getString(column_index);
            }
            cursor.close();
            return res;
        }
    */
    @Override
    public void callback(int id, String subject, String content) {

        if (id == 0) {  // timerille/intervallille varattu

            //Log.v("xxx", "xxxxxx");
            if(!working) {

                msg(findViewById(android.R.id.content));
            }

        } else {

            if (subject == null) {

                Log.v("xxx", "Ei löytynyt viestiä odotellaan... uusi kierros");

            } else {
                // asetetaan muuttuja niin ettei kysellä uutta viestiä kysellään vasta kun tehtävä suoritettu mutta interval elossa
                // toisaalta pitisikö asettaa uudellen päälle ja pois


                Log.v("xxx", "¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤ " + Integer.toString(id));
                //Log.v("xxx", subject);
                //Log.v("xxx", content);

               // content = content.replace("&quot;", "\"");

                try {
                    JSONObject contentJSON = new JSONObject(content);

                    Log.v("xxx","TOKEN= "+contentJSON.getString("Token"));
                    //Log.v("xxx","IP= "+contentJSON.getString("IP"));
                    Log.v("xxx","SocketId= "+contentJSON.getString("SocketId"));
                    Log.v("xxx","Source= "+contentJSON.getString("Source"));

                }catch(Exception ex) {

                    Log.v("xxx", ex.getMessage());
                }


                Log.v("xxx", "¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤¤");
                working=true;
                boolean ret=fakeProcess();
                Log.v("xxx","Process over= "+Boolean.toString(ret));
                working=false;
            }
        }
        //       tp.init(false);
    }

}